package com.example.loginapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Top extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.top);
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findViewById(R.id.contactus).setVisibility(View.VISIBLE);
                findViewById(R.id.images).setVisibility(View.INVISIBLE);
                findViewById(R.id.button).setBackgroundColor(Color.parseColor("#CDD3D3"));
                findViewById(R.id.button1).setBackgroundColor(Color.parseColor("#FFFFFF"));
            }
        });
        findViewById(R.id.button1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findViewById(R.id.images).setVisibility(View.VISIBLE);
                findViewById(R.id.contactus).setVisibility(View.INVISIBLE);
                findViewById(R.id.button1).setBackgroundColor(Color.parseColor("#CDD3D3"));
                findViewById(R.id.button).setBackgroundColor(Color.parseColor("#FFFFFF"));
            }
        });

    }
}
